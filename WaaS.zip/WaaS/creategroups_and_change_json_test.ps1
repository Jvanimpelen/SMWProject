[CmdletBinding()]
param
(
    [Parameter(Mandatory = $true)]
    [string]$Path
)

#find *.json file in the $path folder
$jsonfilesfound = Get-ChildItem -path $path"\Device Configurations" -filter "*.json"

$groupsconversiontable = Get-Content ($path+"\groups.json") -raw | ConvertFrom-Json
#write-host $groupsconversiontable.displayname

 foreach($file in $jsonfilesfound)
{
    write-host $file
    $jsonassignementfile = Get-Content ($path+"\Device Configurations\Assignments\"+$file) -raw | ConvertFrom-Json
    foreach($block in $jsonassignementfile){
        foreach($row in $groupsconversiontable)
        {
           # write-host $row.objectID
            if($block.target.groupId -eq $row.objectid)
              {
                write-host "waar"
                $groupname = $row.displayname   
                $filter = "Displayname eq '$groupname'"
                write-host $filter
                $test = get-azureadgroup -Filter $filter
                if($test -ne $null)
                {     
                    write-host $groupname + " exist"
                    $newgroup = $test
                }
                else
                {
                    write-host $groupname + " does not exist"
                    $newgroup = New-AzureADGroup -DisplayName ($groupname) -Description $groupname  -MailEnabled $false -SecurityEnabled $true -MailNickName "NotSet"
                }               
                    
                    
                $block.target.groupId=$newgroup.objectID
                break
            }
        }        
    }    $jsonassignementfile | ConvertTo-Json -depth 32| set-content ($path+"\Device Configurations\Assignments\"+$file)
}

#find *.json file in the $path folder
$jsonfilesfound = Get-ChildItem -path $path"\Administrative Templates" -filter "*.json"

$groupsconversiontable = Get-Content ($path+"\groups.json") -raw | ConvertFrom-Json
#write-host $groupsconversiontable.displayname

 foreach($file in $jsonfilesfound)
{
    write-host $file
    $jsonassignementfile = Get-Content ($path+"\Administrative Templates\Assignments\"+$file) -raw | ConvertFrom-Json
    foreach($block in $jsonassignementfile){
        foreach($row in $groupsconversiontable)
        {
           # write-host $row.objectID
            if($block.target.groupId -eq $row.objectid)
              {
                write-host "waar"
                $groupname = $row.displayname   
                $filter = "Displayname eq '$groupname'"
                write-host $filter
                $test = get-azureadgroup -Filter $filter
                if($test -ne $null)
                {     
                    write-host $groupname + " exist"
                    $newgroup = $test
                }
                else
                {
                    write-host $groupname + " does not exist"
                    $newgroup = New-AzureADGroup -DisplayName ($groupname) -Description $groupname  -MailEnabled $false -SecurityEnabled $true -MailNickName "NotSet"
                }               
                    
                    
                $block.target.groupId=$newgroup.objectID
                break
            }
        }        
    }    $jsonassignementfile | ConvertTo-Json -depth 32| set-content ($path+"\Administrative Templates\Assignments\"+$file)
}

#start restoring the assignments.

Import-Module -Name IntuneBackupAndRestore
Start-IntuneRestoreAssignments $Path
